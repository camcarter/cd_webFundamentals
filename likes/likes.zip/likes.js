

var likes = 3
function likeHandler(){
    console.log("LIKE HANDLER")

    // INCREMENT LIKES
    likes++

    // METHOD QUERY SELECTION
    var likesButton = document.querySelector(".likes")
    likesButton.innerText = likes + " Like(s)"
}
var likes = 9
function neilHandler(){
    console.log("LIKE HANDLER")

    // INCREMENT LIKES
    likes++

    // METHOD QUERY SELECTION
    var likesButton = document.querySelector(".likes_neil")
    likesButton.innerText = likes + " Like(s)"
}
var likes = 12
function nicholeHandler(){
    console.log("LIKE HANDLER")

    // INCREMENT LIKES
    likes++

    // METHOD QUERY SELECTION
    var likesButton = document.querySelector(".likes_nichole")
    likesButton.innerText = likes + " Like(s)"
}
var likes = 9
function jimHandler(){
    console.log("LIKE HANDLER")

    // INCREMENT LIKES
    likes++

    // METHOD QUERY SELECTION
    var likesButton = document.querySelector(".likes_jim")
    likesButton.innerText = likes + " Like(s)"
}