function clickHandler(element) {
    if (element.innerText=="Login"){
        element.innerText = "Logout";
    }

    else {
        element.innerText="login";
    }
}

function displayLike(elementName)

// METHOD - QUERY SELECTOR
var likes = 13
function likeHandler(){
    console.log("LIKE HANDLER")

    // INCREMENT LIKES
    likes ++
    
}